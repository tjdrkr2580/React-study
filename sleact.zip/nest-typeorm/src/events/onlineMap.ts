export const onlineMap = {};
